# ScratchFormat2
ScratchFormat Rewrite

Uses Remix Icons (https://remixicon.com/) hosted  
on their Github.  

This is a complete rewrite from Scratch, very fast and small compared  
to the older versions.
